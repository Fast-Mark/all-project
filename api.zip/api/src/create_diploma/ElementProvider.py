
class ElementProvider():

    def __init__(self) -> None:
        pass

    def get_next_elements(self):
        pass