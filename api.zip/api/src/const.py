# BASE_PATH = "E:\\programming\\python projects\\testFastApi"

BASE_PATH = "/home/amir/PycharmProjects/main-app/api"
